// Задание: Присвоить классы с помощью JS


// Вам даны два файла HTML и CSS. Но по каким-то причинам, у вас нет доступа к редактированию данных файлов. 
// Но за то вы можете использовать язык JavaScript, чтоб присвоить все классы нужным элементам

// For example:

document.querySelector('header').classList.add('header')
document.querySelector('div').classList.add('header__conten')
document.querySelector('h1').classList.add('header-title')
document.querySelector('menu').classList.add('menu-item')
document.querySelector('li').classList.add('header-menu__item')
document.querySelector('button').classList.add('menu-btn')
document.querySelector('main').classList.add('main')
document.querySelector('section').classList.add('cards-main')
document.querySelector('div').classList.add('cards-list')
document.querySelector('img').classList.add('main-img')
document.querySelector('h3').classList.add('main-title')
document.querySelector('p').classList.add('main-text')
document.querySelector('div').classList.add('container')
document.querySelector('p').classList.add('text-container')
document.querySelector("button").classList.add('btn')

// and etc. 